package com.glowxgaara.check

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Best-effort root / tamper indicators. A well-hidden root (Magisk with DenyList, KernelSU, etc.)
 * can evade on-device checks, so treat "clean" as "no indicators", not proof.
 * For a strong result add Play Integrity verification on your server (see README).
 */
object RootChecker {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sd/xbin/su",
        "/system/bin/.ext/.su", "/data/local/xbin/su", "/data/local/bin/su", "/data/local/su",
        "/system/app/Superuser.apk", "/sbin/magisk", "/data/adb/magisk", "/data/adb/modules",
        "/data/adb/ksu", "/data/adb/ap"
    )

    fun scan(ctx: Context): Section {
        val f = mutableListOf<Finding>()
        var rooted = false

        val found = suPaths.filter { File(it).exists() }
        if (found.isNotEmpty()) {
            rooted = true
            f += Finding("Root files found", found.joinToString("\n"), Severity.FAIL)
        }

        val which = try {
            Runtime.getRuntime().exec(arrayOf("which", "su")).inputStream
                .bufferedReader().use { it.readText().trim() }
        } catch (e: Exception) {
            ""
        }
        if (which.isNotEmpty()) {
            rooted = true
            f += Finding("su binary reachable", which, Severity.FAIL)
        }

        if (Build.TAGS?.contains("test-keys") == true) {
            rooted = true
            f += Finding("Build signed with test-keys", "Custom or modified ROM", Severity.FAIL)
        }

        if (Util.prop("ro.debuggable") == "1") {
            rooted = true
            f += Finding("ro.debuggable = 1", "Debuggable system image", Severity.FAIL)
        }
        if (Util.prop("ro.secure") == "0") {
            rooted = true
            f += Finding("ro.secure = 0", "Insecure system image", Severity.FAIL)
        }

        // Bootloader / verified boot
        val vb = Util.prop("ro.boot.verifiedbootstate")
        if (vb == "orange" || vb == "red") {
            f += Finding("Verified boot: $vb", "Bootloader unlocked or system modified", Severity.FAIL)
            rooted = true
        } else if (vb == "green") {
            f += Finding("Verified boot: green", "Bootloader locked, system verified", Severity.OK)
        }
        if (Util.prop("ro.boot.flash.locked") == "0") {
            f += Finding("Bootloader unlocked", "ro.boot.flash.locked = 0", Severity.WARN)
        }

        // SELinux
        val se = try {
            Runtime.getRuntime().exec(arrayOf("getenforce")).inputStream.bufferedReader().use { it.readText().trim() }
        } catch (e: Exception) {
            ""
        }
        if (se.equals("Permissive", true)) {
            f += Finding("SELinux permissive", "Security policy relaxed", Severity.FAIL)
            rooted = true
        }

        // Writable system partitions
        try {
            val rw = File("/proc/mounts").readLines().filter { line ->
                val p = line.split(" ")
                p.size > 3 && (p[1] == "/system" || p[1] == "/") && p[3].split(",").contains("rw")
            }
            if (rw.isNotEmpty()) {
                rooted = true
                f += Finding("System partition mounted read-write", rw.first(), Severity.FAIL)
            }
        } catch (_: Exception) {
        }

        if (!rooted) {
            f += Finding(
                "No root indicators found",
                "Hidden root can evade on-device checks. Use Play Integrity for a strong verdict.",
                Severity.OK
            )
        } else {
            f.add(0, Finding("ROOT / MODIFIED SYSTEM DETECTED", "", Severity.FAIL))
        }
        return Section("Root and system integrity", f)
    }
}
