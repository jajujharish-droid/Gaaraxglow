package com.glowxgaara.check

enum class Severity { OK, INFO, WARN, FAIL }

data class Finding(
    val title: String,
    val detail: String = "",
    val severity: Severity = Severity.INFO
)

data class Section(val name: String, val findings: List<Finding>)

fun List<Section>.verdict(): Severity =
    flatMap { it.findings }.maxOfOrNull { it.severity } ?: Severity.OK

/** 0-100 trust score: each FAIL costs 25 points, each WARN costs 7. */
fun List<Section>.score(): Int {
    val all = flatMap { it.findings }
    val fails = all.count { it.severity == Severity.FAIL }
    val warns = all.count { it.severity == Severity.WARN }
    return (100 - fails * 25 - warns * 7).coerceIn(0, 100)
}
