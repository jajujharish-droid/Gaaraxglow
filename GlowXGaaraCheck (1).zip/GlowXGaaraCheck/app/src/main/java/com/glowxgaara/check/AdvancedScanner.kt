package com.glowxgaara.check

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Debug
import android.provider.Settings
import java.io.ByteArrayInputStream
import java.io.File
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

/** Hooking, injection, debugging, mount-trace, repackaging and network checks. */
object AdvancedScanner {
    private val hookMarkers = listOf(
        "frida", "gum-js", "xposed", "lsposed", "edxposed", "substrate",
        "zygisk", "riru", "gameguardian"
    )

    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "com.huawei.appmarket", "com.xiaomi.mipicks", "com.heytap.market", "com.vivo.appstore"
    )

    fun scan(ctx: Context): Section {
        val f = mutableListOf<Finding>()
        f += hookChecks()
        f += debugChecks()
        f += mountChecks()
        f += fridaChecks()
        f += repackagedApps(ctx)
        f += networkChecks(ctx)
        val dbg = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        f += Finding("Scanner build", if (dbg) "Debug" else "Release")
        return Section("Advanced detection", f)
    }

    // Hook / injection libraries mapped into this process, Xposed classes, hooked call stack
    private fun hookChecks(): List<Finding> {
        val out = mutableListOf<Finding>()
        try {
            val hits = File("/proc/self/maps").readLines()
                .map { it.lowercase() }
                .filter { line -> hookMarkers.any { line.contains(it) } }
                .map { it.substringAfterLast(' ') }
                .distinct()
            out += if (hits.isNotEmpty())
                Finding("Hook/injection libraries in memory", hits.take(8).joinToString("\n"), Severity.FAIL)
            else Finding("No hook libraries in process memory", "", Severity.OK)
        } catch (e: Exception) {
            out += Finding("Process memory map unreadable", "", Severity.INFO)
        }

        val classes = listOf(
            "de.robv.android.xposed.XposedBridge",
            "de.robv.android.xposed.XC_MethodHook",
            "org.lsposed.lspd.core.Main"
        ).filter { n ->
            try {
                Class.forName(n)
                true
            } catch (t: Throwable) {
                false
            }
        }
        if (classes.isNotEmpty())
            out += Finding("Xposed/LSPosed classes loaded", classes.joinToString("\n"), Severity.FAIL)

        val frames = Throwable().stackTrace.filter {
            it.className.contains("xposed", true) || it.className.contains("lspd", true)
        }
        if (frames.isNotEmpty())
            out += Finding("Hooking frames in call stack", frames.first().className, Severity.FAIL)
        return out
    }

    // Debugger or ptrace attached
    private fun debugChecks(): List<Finding> {
        val out = mutableListOf<Finding>()
        if (Debug.isDebuggerConnected()) out += Finding("Debugger attached", "", Severity.FAIL)
        val tracer = try {
            File("/proc/self/status").readLines()
                .firstOrNull { it.startsWith("TracerPid") }
                ?.substringAfter(":")?.trim()?.toIntOrNull()
        } catch (e: Exception) {
            null
        }
        if (tracer != null && tracer != 0)
            out += Finding("Process is being traced", "TracerPid = $tracer (ptrace / Frida)", Severity.FAIL)
        else if (tracer == 0)
            out += Finding("No debugger or tracer attached", "", Severity.OK)
        return out
    }

    // Magisk / Zygisk mounts leave traces even when the su binary is hidden
    private fun mountChecks(): List<Finding> = try {
        val hits = File("/proc/self/mountinfo").readLines().filter { l ->
            val s = l.lowercase()
            s.contains("magisk") || s.contains("zygisk") || s.contains("/data/adb")
        }
        if (hits.isNotEmpty())
            listOf(Finding("Root mount traces", hits.take(3).joinToString("\n") { it.takeLast(90) }, Severity.FAIL))
        else listOf(Finding("No root mount traces", "", Severity.OK))
    } catch (e: Exception) {
        emptyList()
    }

    // Frida server files and listening port 27042
    private fun fridaChecks(): List<Finding> {
        val out = mutableListOf<Finding>()
        val files = listOf(
            "/data/local/tmp/frida-server", "/data/local/tmp/re.frida.server",
            "/data/local/tmp/frida-gadget.so", "/data/local/tmp/frida-agent.so"
        ).filter { File(it).exists() }
        if (files.isNotEmpty()) out += Finding("Frida files found", files.joinToString("\n"), Severity.FAIL)

        val hexPort = ":%04X".format(27042)
        val listening = listOf("/proc/net/tcp", "/proc/net/tcp6").any { p ->
            try {
                File(p).readLines().drop(1).any { l ->
                    val c = l.trim().split(Regex("\\s+"))
                    c.size > 3 && c[1].endsWith(hexPort) && c[3] == "0A"
                }
            } catch (e: Exception) {
                false
            }
        }
        if (listening) out += Finding("Frida server port 27042 is listening", "", Severity.FAIL)
        if (out.isEmpty()) out += Finding("No Frida traces found", "", Severity.OK)
        return out
    }

    // Sideloaded apps signed with the public Android debug key are usually repackaged/modded APKs
    @Suppress("DEPRECATION")
    private fun repackagedApps(ctx: Context): List<Finding> {
        val pm = ctx.packageManager
        val flag = if (Build.VERSION.SDK_INT >= 28)
            PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val cf = CertificateFactory.getInstance("X.509")
        val bad = mutableListOf<String>()
        for (ai in pm.getInstalledApplications(0)) {
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || ai.packageName == ctx.packageName) continue
            if (Util.installer(pm, ai.packageName) in trustedStores) continue
            val pi = try {
                pm.getPackageInfo(ai.packageName, flag)
            } catch (e: Exception) {
                continue
            }
            val sig = firstSig(pi) ?: continue
            try {
                val c = cf.generateCertificate(ByteArrayInputStream(sig.toByteArray())) as X509Certificate
                if (c.subjectX500Principal.name.contains("Android Debug", true))
                    bad += "${pm.getApplicationLabel(ai)} (${ai.packageName})"
            } catch (e: Exception) {
            }
        }
        return if (bad.isEmpty()) listOf(Finding("No debug-signed sideloaded apps", "", Severity.OK))
        else listOf(
            Finding(
                "Debug-signed sideloaded apps (${bad.size})",
                "Often repackaged or modded APKs.\n" + bad.take(10).joinToString("\n"),
                Severity.WARN
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun firstSig(pi: PackageInfo): Signature? =
        if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners?.firstOrNull()
        else pi.signatures?.firstOrNull()

    // VPN / proxy / Play Protect
    private fun networkChecks(ctx: Context): List<Finding> {
        val out = mutableListOf<Finding>()
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            out += if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
                Finding("VPN is active", "Allowed, but note it in tournaments that restrict VPNs.", Severity.INFO)
            else Finding("No VPN active", "", Severity.OK)
        } catch (e: Exception) {
        }
        val proxy = System.getProperty("http.proxyHost")
        if (!proxy.isNullOrBlank()) out += Finding("HTTP proxy configured", proxy, Severity.WARN)
        val protect = Settings.Global.getInt(ctx.contentResolver, "package_verifier_enable", -1)
        if (protect == 0) out += Finding("Play Protect app scanning is off", "", Severity.WARN)
        return out
    }
}
