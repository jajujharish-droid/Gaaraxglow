package com.glowxgaara.check

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import android.provider.Settings

/** Scans installed apps for known cheat/root/hook tools and risky sideloaded apps. */
object AppScanner {

    /** Extend freely. Cheat tools often rename themselves, so keywords below back this up. */
    private val known = mapOf(
        "com.topjohnwu.magisk" to "Magisk (root manager)",
        "io.github.vvb2060.magisk" to "Magisk Alpha/Delta (root manager)",
        "me.weishu.kernelsu" to "KernelSU (root)",
        "me.bmax.apatch" to "APatch (root)",
        "eu.chainfire.supersu" to "SuperSU (root)",
        "com.koushikdutta.superuser" to "Superuser (root)",
        "org.lsposed.manager" to "LSPosed (hooking framework)",
        "de.robv.android.xposed.installer" to "Xposed Installer (hooking framework)",
        "io.va.exposed" to "VirtualXposed (hooking in a virtual space)",
        "com.chelpus.lackypatch" to "Lucky Patcher",
        "com.android.vending.billing.InAppBillingService.COIN" to "Lucky Patcher (billing hack)",
        "catch_.me_.if_.you_.can_" to "GameGuardian (memory editor)",
        "com.cih.game_cih" to "CIH game cheat tool",
        "com.lbe.parallel.intl" to "Parallel Space (app cloner)",
        "com.ludashi.dualspace" to "Dual Space (app cloner)",
        "com.vmos.app" to "VMOS (virtual phone)"
    )

    private val keywords = listOf(
        "gameguardian", "game guardian", "lucky patcher", "xposed", "magisk", "cheat", "hack",
        "injector", "mod menu", "modmenu", "aimbot", "speed hack", "speedhack", "app cloner",
        "dual space", "parallel space", "virtual space", "virtual android"
    )

    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "com.huawei.appmarket", "com.xiaomi.mipicks", "com.heytap.market", "com.vivo.appstore"
    )

    private data class Row(
        val pkg: String, val label: String, val installer: String?,
        val firstInstall: Long, val lastUpdate: Long, val perms: Set<String>
    )

    @Suppress("DEPRECATION")
    fun scan(ctx: Context): Section {
        val pm = ctx.packageManager
        val f = mutableListOf<Finding>()

        val rows = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS).mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) return@mapNotNull null
            if (pi.packageName == ctx.packageName) return@mapNotNull null
            Row(
                pi.packageName, pm.getApplicationLabel(ai).toString(),
                Util.installer(pm, pi.packageName), pi.firstInstallTime, pi.lastUpdateTime,
                pi.requestedPermissions?.toSet() ?: emptySet()
            )
        }
        f += Finding("User-installed apps scanned", rows.size.toString())

        // Known tools
        val hits = rows.filter { known.containsKey(it.pkg) }
        hits.forEach { f += Finding("Known tool: ${known[it.pkg]}", "${it.label}  (${it.pkg})", Severity.FAIL) }

        // Keyword heuristics (review manually, may include false positives)
        rows.filter { r -> !known.containsKey(r.pkg) && keywords.any { k -> (r.label + " " + r.pkg).lowercase().contains(k) } }
            .forEach { f += Finding("Suspicious name", "${it.label}  (${it.pkg})", Severity.WARN) }

        // Sideloaded apps that can draw over other apps
        rows.filter { it.installer !in trustedStores && "android.permission.SYSTEM_ALERT_WINDOW" in it.perms }
            .forEach { f += Finding("Sideloaded app with draw-over-apps", "${it.label}  (${it.pkg})", Severity.WARN) }

        // Sideloaded accessibility services (auto-aim / macro tools)
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(":")?.mapNotNull { it.substringBefore("/").ifBlank { null } }?.toSet() ?: emptySet()
        rows.filter { it.pkg in enabled && it.installer !in trustedStores }
            .forEach { f += Finding("Sideloaded accessibility service active", "${it.label}  (${it.pkg})", Severity.WARN) }

        // Virtual environment / clone detection
        val path = ctx.filesDir.absolutePath
        if (!(path.startsWith("/data/user/0/") || path.startsWith("/data/data/"))) {
            f += Finding("Running inside a virtual space or clone?", path, Severity.WARN)
        }
        if (Process.myUid() / 100000 != 0) {
            f += Finding("Secondary user / work profile", "Not the primary Android user", Severity.INFO)
        }

        // Recent installs (last 7 days)
        val week = System.currentTimeMillis() - 7 * 86_400_000L
        val recent = rows.filter { it.firstInstall > week }.sortedByDescending { it.firstInstall }
        if (recent.isNotEmpty()) {
            f += Finding(
                "Installed in the last 7 days (${recent.size})",
                recent.take(12).joinToString("\n") { "${it.label} - ${Util.date(it.firstInstall)}" }
            )
        }

        // Install history: compare with the snapshot from the previous scan.
        // Android does not keep a list of uninstalled apps, so history starts from the first scan.
        val prefs = ctx.getSharedPreferences("glow_prefs", Context.MODE_PRIVATE)
        val now = rows.associate { it.pkg to it.label }
        val before = prefs.getStringSet("snapshot", null)
        if (before == null) {
            f += Finding("Install history", "First scan. Baseline saved; future scans show what was added or removed.")
        } else {
            val removed = before.filter { it !in now.keys }
            val added = now.keys.filter { it !in before }
            val last = prefs.getLong("snapshot_time", 0L)
            if (last > 0) f += Finding("Previous scan", Util.date(last))
            removed.forEach {
                val bad = known.containsKey(it)
                f += Finding(
                    if (bad) "Known tool uninstalled since last scan" else "Uninstalled since last scan",
                    it, if (bad) Severity.WARN else Severity.INFO
                )
            }
            if (added.isNotEmpty()) f += Finding("New since last scan", added.joinToString("\n") { "${now[it]} ($it)" })
        }
        prefs.edit().putStringSet("snapshot", now.keys.toSet()).putLong("snapshot_time", System.currentTimeMillis()).apply()

        if (f.none { it.severity >= Severity.WARN }) f += Finding("No suspicious apps found", "", Severity.OK)
        return Section("Installed apps", f)
    }
}
