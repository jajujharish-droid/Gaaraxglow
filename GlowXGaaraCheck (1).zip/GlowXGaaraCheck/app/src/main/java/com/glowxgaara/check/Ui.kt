package com.glowxgaara.check

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0F14)
private val Card = Color(0xFF141A22)
private val Glow = Color(0xFF7CFFB2)
private val Violet = Color(0xFFB388FF)

private fun Severity.color() = when (this) {
    Severity.OK -> Color(0xFF4ADE80)
    Severity.INFO -> Color(0xFF60A5FA)
    Severity.WARN -> Color(0xFFFBBF24)
    Severity.FAIL -> Color(0xFFF87171)
}

@Composable
fun GlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Glow, secondary = Violet, background = Bg, surface = Card)
    ) { Surface(color = Bg, modifier = Modifier.fillMaxSize(), content = content) }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("glow_prefs", Context.MODE_PRIVATE) }
    var consent by remember { mutableStateOf(prefs.getBoolean("consent", false)) }
    if (!consent) ConsentScreen { prefs.edit().putBoolean("consent", true).apply(); consent = true }
    else Dashboard()
}

@Composable
fun Title() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("GLOW X GAARA CHECK", color = Glow, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("Fair-play device check", color = Violet, fontSize = 13.sp)
        }
    }
}

@Composable
fun ConsentScreen(onAccept: () -> Unit) {
    var agreed by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).systemBarsPadding()) {
        Title()
        Spacer(Modifier.height(20.dp))
        Text("Before we start", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "To keep matches fair, this app checks your device. It looks at:\n\n" +
                "- Root / bootloader / modified system indicators\n" +
                "- Hooking, injection and debugging tools (such as Frida or Xposed)\n" +
                "- Installed apps (names, install source, install dates) and changes since the last scan\n" +
                "- Last restart time and Android security-patch date\n" +
                "- Whether a VPN or proxy is active (yes/no only)\n" +
                "- The selected game's APK signature, files and (if you allow it) its data folder\n\n" +
                "It does NOT read your messages, photos, contacts, passwords or personal files. " +
                "Everything runs on your device and results stay on screen. Nothing is uploaded; " +
                "you choose whether to share the report.",
            lineHeight = 21.sp
        )
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(agreed, { agreed = it })
            Text("I understand and agree to this check on my device")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onAccept, enabled = agreed, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
    }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sections by remember { mutableStateOf<List<Section>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var game by remember { mutableIntStateOf(0) }
    var tree by remember { mutableStateOf<Uri?>(null) }

    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree = it }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT <= 29 &&
            ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).systemBarsPadding()) {
        Title()
        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GameTargets.list.forEachIndexed { i, g ->
                FilterChip(selected = game == i, onClick = { game = i }, label = { Text(g.label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                val hint = DocumentsContract.buildTreeDocumentUri("com.android.externalstorage.documents", "primary:Android/obb")
                treeLauncher.launch(hint)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (tree == null) "Pick game data folder (optional)" else "Data folder selected") }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                scope.launch {
                    scanning = true
                    sections = withContext(Dispatchers.IO) {
                        listOf(
                            SystemScanner.scan(ctx), RootChecker.scan(ctx), AppScanner.scan(ctx),
                            AdvancedScanner.scan(ctx),
                            GameScanner.scan(ctx, GameTargets.list[game], tree)
                        )
                    }
                    scanning = false
                }
            },
            enabled = !scanning,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (scanning) "Scanning..." else "Run full scan") }

        if (scanning) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }

        if (sections.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            val v = sections.verdict()
            Column(
                Modifier.fillMaxWidth().background(v.color().copy(alpha = 0.15f), RoundedCornerShape(12.dp)).padding(16.dp)
            ) {
                Text(
                    when (v) {
                        Severity.OK, Severity.INFO -> "FAIR: no problems found"
                        Severity.WARN -> "REVIEW NEEDED: suspicious items found"
                        Severity.FAIL -> "NOT FAIR: violation indicators found"
                    },
                    color = v.color(), fontWeight = FontWeight.Bold, fontSize = 17.sp
                )
                Spacer(Modifier.height(4.dp))
                Text("Trust score: ${sections.score()} / 100", color = v.color(), fontSize = 14.sp)
            }
            sections.forEach { s ->
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(14.dp)) {
                    Text(s.name, color = Glow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    s.findings.forEach { fd ->
                        Spacer(Modifier.height(8.dp))
                        Text(fd.title, color = fd.severity.color(), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        if (fd.detail.isNotBlank()) Text(fd.detail, fontSize = 12.sp, color = Color(0xFFB8C1CC))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { share(ctx, sections) }, modifier = Modifier.fillMaxWidth()) { Text("Share report") }
        }
    }
}

private fun share(ctx: Context, sections: List<Section>) {
    val body = buildString {
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
        appendLine("Time: ${Util.date(System.currentTimeMillis())}")
        appendLine("Verdict: ${sections.verdict()}   Trust score: ${sections.score()}/100")
        sections.forEach { s ->
            appendLine("\n== ${s.name} ==")
            s.findings.forEach { appendLine("[${it.severity}] ${it.title}${if (it.detail.isNotBlank()) " - " + it.detail.replace("\n", "; ") else ""}") }
        }
    }
    val id = Util.sha256(body.toByteArray()).take(12)
    val text = "Glow X Gaara Check report\nReport ID: $id\n$body"
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    ctx.startActivity(Intent.createChooser(i, "Share report"))
}
