package com.glowxgaara.check

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Util {
    fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    fun sha256(bytes: ByteArray): String =
        hex(MessageDigest.getInstance("SHA-256").digest(bytes))

    fun sha256(input: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(1 shl 16)
        input.use {
            while (true) {
                val n = it.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return hex(md.digest())
    }

    fun date(ms: Long): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

    fun prop(name: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", name))
            .inputStream.bufferedReader().use { it.readText().trim() }
    } catch (e: Exception) {
        ""
    }

    @Suppress("DEPRECATION")
    fun pkg(pm: PackageManager, name: String): PackageInfo? = try {
        val sig = if (Build.VERSION.SDK_INT >= 28)
            PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        pm.getPackageInfo(name, sig or PackageManager.GET_PERMISSIONS)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    fun versionCode(pi: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
}
