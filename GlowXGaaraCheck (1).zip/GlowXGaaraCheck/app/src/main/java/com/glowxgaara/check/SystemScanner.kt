package com.glowxgaara.check

import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Last restart, OS patch level, developer settings, emulator and clock checks. */
object SystemScanner {
    fun scan(ctx: Context): Section {
        val f = mutableListOf<Finding>()
        val cr = ctx.contentResolver

        // 1) Last restart
        val up = SystemClock.elapsedRealtime()
        val boot = System.currentTimeMillis() - up
        val days = up / 86_400_000.0
        f += Finding("Last restart", "${Util.date(boot)}  (up %.1f days)".format(days))
        if (up < 15 * 60_000L) {
            f += Finding(
                "Device restarted very recently",
                "Less than 15 minutes ago. Review if this happened right before a match.",
                Severity.WARN
            )
        }

        // 2) OS update info
        f += Finding("Android version", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        f += Finding("Firmware build date", Util.date(Build.TIME))
        val patch = Build.VERSION.SECURITY_PATCH
        val age = try {
            ChronoUnit.DAYS.between(LocalDate.parse(patch), LocalDate.now())
        } catch (e: Exception) {
            null
        }
        f += when {
            age == null -> Finding("Security patch", patch.ifBlank { "unknown" })
            age > 365 -> Finding("Security patch", "$patch  ($age days old, outdated)", Severity.WARN)
            else -> Finding("Security patch", "$patch  ($age days old)", Severity.OK)
        }

        // 3) Settings that matter for fairness
        val dev = Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        val adb = Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1
        f += Finding("Developer options", if (dev) "Enabled" else "Disabled", if (dev) Severity.INFO else Severity.OK)
        f += Finding("USB debugging", if (adb) "Enabled" else "Disabled", if (adb) Severity.WARN else Severity.OK)

        val autoTime = Settings.Global.getInt(cr, Settings.Global.AUTO_TIME, 1) == 1
        f += Finding(
            "Automatic date and time",
            if (autoTime) "On" else "Off (clock can be manipulated)",
            if (autoTime) Severity.OK else Severity.WARN
        )

        // 4) Emulator
        val emu = Build.FINGERPRINT.startsWith("generic") ||
            Build.HARDWARE.contains("goldfish") || Build.HARDWARE.contains("ranchu") ||
            Build.MODEL.contains("Emulator", true) || Build.MANUFACTURER.contains("Genymotion", true) ||
            Build.PRODUCT.contains("sdk", true)
        f += if (emu) Finding("Emulator", "Running on an emulator", Severity.FAIL)
        else Finding("Emulator", "Real device", Severity.OK)

        f += Finding("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
        return Section("System", f)
    }
}
