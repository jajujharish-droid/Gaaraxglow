package com.glowxgaara.check

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.Signature
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

/**
 * Games to verify. To enable the signature check, run the app once on a clean device that installed
 * the game from the official store, copy the shown certificate SHA-256 into officialCerts, and rebuild.
 */
data class GameTarget(val label: String, val pkg: String, val officialCerts: Set<String> = emptySet())

object GameTargets {
    val list = listOf(
        GameTarget("Free Fire", "com.dts.freefireth"),
        GameTarget("Free Fire MAX", "com.dts.freefiremax")
    )
}

data class FileEntry(val rel: String, val size: Long, val modified: Long, val open: () -> InputStream?)

object FileWalker {
    fun fromTree(ctx: Context, tree: Uri, limit: Int = 20000): List<FileEntry> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = ArrayList<FileEntry>()
        fun walk(d: DocumentFile, prefix: String) {
            for (c in d.listFiles()) {
                if (out.size >= limit) return
                val n = c.name ?: continue
                if (c.isDirectory) walk(c, "$prefix$n/")
                else out += FileEntry("$prefix$n", c.length(), c.lastModified()) {
                    ctx.contentResolver.openInputStream(c.uri)
                }
            }
        }
        walk(root, "")
        return out
    }

    fun fromDir(dir: File, prefix: String, limit: Int = 20000): List<FileEntry> =
        dir.walkTopDown().filter { it.isFile }.take(limit).map {
            FileEntry(prefix + it.relativeTo(dir).path, it.length(), it.lastModified()) { it.inputStream() }
        }.toList()
}

object GameScanner {
    private val badLibMarkers = listOf("frida", "xposed", "substrate", "lsposed", "gameguardian", "speedhack", "magisk")
    private val riskyExt = listOf(".so", ".dex", ".apk", ".jar", ".sh")
    private val goodInstallers = setOf("com.android.vending")

    fun scan(ctx: Context, t: GameTarget, dataTree: Uri?): Section {
        val pm = ctx.packageManager
        val title = "${t.label} integrity"
        val pi = Util.pkg(pm, t.pkg)
            ?: return Section(title, listOf(Finding("${t.label} is not installed", t.pkg)))
        val ai = pi.applicationInfo ?: return Section(title, listOf(Finding("No app info", t.pkg, Severity.WARN)))
        val f = mutableListOf<Finding>()

        f += Finding("Version", "${pi.versionName} (code ${Util.versionCode(pi)})")
        f += Finding("Installed / last updated", "${Util.date(pi.firstInstallTime)}  /  ${Util.date(pi.lastUpdateTime)}")

        // Signature
        val certs = certHashes(pi)
        if (t.officialCerts.isEmpty()) {
            f += Finding(
                "Signing certificate (no official baseline configured)",
                certs.joinToString("\n").ifBlank { "unreadable" }, Severity.INFO
            )
        } else {
            val official = t.officialCerts.map { it.replace(":", "").lowercase() }.toSet()
            f += if (certs.isNotEmpty() && certs.all { it in official })
                Finding("Signature matches official build", "", Severity.OK)
            else Finding(
                "SIGNATURE DOES NOT MATCH OFFICIAL",
                "Re-signed or modified APK.\n" + certs.joinToString("\n"), Severity.FAIL
            )
        }

        // Installer
        val inst = Util.installer(pm, t.pkg)
        f += if (inst in goodInstallers) Finding("Installed from Google Play", "", Severity.OK)
        else Finding("Not installed from Google Play", "Installer: ${inst ?: "unknown / sideloaded"}", Severity.WARN)

        if ((ai.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0)
            f += Finding("Debuggable build", "Official builds are not debuggable", Severity.FAIL)

        // APK files: hashes + contents
        val paths = listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        val apkLibs = mutableSetOf<String>()
        var dexCount = 0
        val hashes = mutableListOf<String>()
        for (p in paths) {
            val file = File(p)
            val h = try { Util.sha256(file.inputStream()) } catch (e: Exception) { "unreadable" }
            hashes += h
            f += Finding("APK ${file.name}", "${file.length() / 1024} KB\nsha256 $h")
            try {
                ZipFile(file).use { z ->
                    for (e in z.entries()) {
                        val name = e.name.lowercase()
                        val base = name.substringAfterLast('/')
                        if (Regex("classes\\d*\\.dex").matches(base)) dexCount++
                        if (name.startsWith("lib/") && name.endsWith(".so")) apkLibs += base
                        if (badLibMarkers.any { base.contains(it) })
                            f += Finding("Injector/hook file inside APK", e.name, Severity.FAIL)
                    }
                }
            } catch (e: Exception) {
                f += Finding("Could not read APK contents", file.name, Severity.WARN)
            }
        }
        f += Finding("DEX files in APK", dexCount.toString())

        // Tamper since last scan: same version number but different APK bytes
        val gp = ctx.getSharedPreferences("glow_prefs", Context.MODE_PRIVATE)
        val ver = Util.versionCode(pi).toString()
        val digest = Util.sha256(hashes.joinToString(",").toByteArray())
        val prev = gp.getString("game_${t.pkg}", null)?.split("|")
        if (prev != null && prev.size == 2) {
            f += when {
                prev[1] == digest -> Finding("Game APK unchanged since last scan", "", Severity.OK)
                prev[0] == ver -> Finding(
                    "GAME APK CHANGED WITHOUT A VERSION CHANGE",
                    "Possible patched or modded APK", Severity.FAIL
                )
                else -> Finding("Game updated since last scan", "Version code ${prev[0]} to $ver")
            }
        }
        gp.edit().putString("game_${t.pkg}", "$ver|$digest").apply()

        // Native libs on disk that are not part of the APK
        val onDisk = File(ai.nativeLibraryDir ?: "").listFiles()?.filter { it.name.endsWith(".so") }?.map { it.name.lowercase() }
        if (!onDisk.isNullOrEmpty() && apkLibs.isNotEmpty()) {
            val extra = onDisk.filter { it !in apkLibs }
            f += if (extra.isNotEmpty()) Finding("Native libraries not from the APK", extra.joinToString("\n"), Severity.FAIL)
            else Finding("Native libraries match the APK", "${onDisk.size} libraries", Severity.OK)
        }

        // Game data (obb / data)
        val entries: List<FileEntry>? = when {
            dataTree != null -> FileWalker.fromTree(ctx, dataTree)
            Build.VERSION.SDK_INT <= 29 -> listOf("obb", "data").mapNotNull {
                File(Environment.getExternalStorageDirectory(), "Android/$it/${t.pkg}").takeIf { d -> d.isDirectory }
                    ?.let { d -> FileWalker.fromDir(d, "$it/") }
            }.flatten()
            else -> null
        }
        if (entries == null) {
            f += Finding(
                "Game data folder not scanned",
                "Tap 'Pick game data folder' and choose Android/obb/${t.pkg}. Newer Android versions may block this folder; APK checks above still apply.",
                Severity.INFO
            )
        } else {
            f += dataFindings(ctx, t, entries)
        }
        return Section(title, f)
    }

    private fun dataFindings(ctx: Context, t: GameTarget, entries: List<FileEntry>): List<Finding> {
        val f = mutableListOf<Finding>()
        f += Finding("Game data files", "${entries.size} files, ${entries.sumOf { it.size } / (1024 * 1024)} MB")

        entries.filter { e -> riskyExt.any { e.rel.lowercase().endsWith(it) } }.take(15)
            .forEach { f += Finding("Executable code in game data", it.rel, Severity.WARN) }

        val day = System.currentTimeMillis() - 86_400_000L
        val fresh = entries.count { it.modified > day }
        if (fresh > 0) f += Finding("Modified in the last 24 hours", "$fresh files")

        val manifest = loadManifest(ctx, t.pkg)
        if (manifest == null) {
            f += Finding("No official file manifest", "Add assets/official_manifest.json to compare file hashes.")
        } else {
            val byName = entries.associateBy { it.rel }
            var bad = 0
            var checked = 0
            for ((rel, hash) in manifest) {
                val e = byName[rel]
                if (e == null) { f += Finding("Missing official file", rel, Severity.WARN); continue }
                val h = try { e.open()?.let { Util.sha256(it) } } catch (ex: Exception) { null }
                checked++
                if (h != hash) { bad++; f += Finding("MODIFIED FILE", rel, Severity.FAIL) }
            }
            val unknown = entries.filter { it.rel !in manifest }
            if (unknown.isNotEmpty())
                f += Finding("Files not in official manifest (${unknown.size})", unknown.take(12).joinToString("\n") { it.rel }, Severity.WARN)
            if (bad == 0 && checked > 0) f += Finding("All $checked manifest files match", "", Severity.OK)
        }
        return f
    }

    private fun loadManifest(ctx: Context, pkg: String): Map<String, String>? = try {
        val json = JSONObject(ctx.assets.open("official_manifest.json").bufferedReader().use { it.readText() })
        json.optJSONObject(pkg)?.let { o -> o.keys().asSequence().associateWith { o.getString(it).lowercase() } }
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun certHashes(pi: PackageInfo): List<String> {
        val sigs: Array<Signature>? = if (Build.VERSION.SDK_INT >= 28) {
            pi.signingInfo?.let { if (it.hasMultipleSigners()) it.apkContentsSigners else it.signingCertificateHistory }
        } else pi.signatures
        return sigs?.map { Util.sha256(it.toByteArray()) } ?: emptyList()
    }
}
