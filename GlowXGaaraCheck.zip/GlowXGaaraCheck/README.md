# Glow X Gaara Check

Fair-play device check for Android (Kotlin + Jetpack Compose). Players install it, accept a consent screen, and run a scan. Results are shown on the device; nothing is uploaded unless the player taps **Share report**.

## What it checks

| Area | Checks |
|---|---|
| Root / system | su binaries, Magisk/KernelSU/APatch paths, test-keys, ro.debuggable, ro.secure, verified-boot state, unlocked bootloader, SELinux permissive, writable /system |
| Apps | Known cheat/root/hook/cloner packages, suspicious names, sideloaded apps with draw-over-apps, sideloaded accessibility services, virtual-space/clone detection, apps installed in last 7 days, **install history diff** (added / removed since last scan) |
| System | Last restart time, OS patch date, firmware build date, USB debugging, developer options, auto date/time, emulator |
| Game (Free Fire / MAX) | Signing certificate vs official, install source, debuggable flag, APK SHA-256, injector/hook files inside APK, native libs not belonging to APK, game data folder scan (executable files, optional hash manifest) |

## Build

1. Install Android Studio (Koala or newer).
2. Open the `GlowXGaaraCheck` folder, let Gradle sync (it creates the wrapper).
3. Run on a device, or Build > Build APK(s).

## Setup you must do (for the strongest results)

1. **Official signature**: install Free Fire from Google Play on a clean phone, run the app, copy the shown certificate SHA-256 and paste it into `officialCerts` in `GameScanner.kt` (`GameTargets`). Then any re-signed/modded APK shows as FAIL.
2. **File manifest (optional)**: put SHA-256 hashes of the official obb/data files in `app/src/main/assets/official_manifest.json`:
   ```json
   { "com.dts.freefireth": { "main.1234.com.dts.freefireth.obb": "<sha256>" } }
   ```
   Keys are paths relative to the folder the player picks.
3. **Extend the lists**: add cheat package names in `AppScanner.known` and keywords in `AppScanner.keywords`.

## Honest limitations

- Android does not keep a list of uninstalled apps. Install history starts at the first scan on that device; run it on every match.
- On-device root checks can be bypassed (Magisk DenyList, etc.). For a strong verdict add Google **Play Integrity API** and verify the token on your server.
- Android 11+ restricts access to other apps' `Android/data` and `Android/obb` folders, and Android 13+ typically blocks picking them. The APK-level checks (signature, hashes, injected libs) work on every version.
- Checks are heuristics: always treat WARN as "review", and FAIL as strong evidence.
- Use it only with player consent (built into the first screen), and tell players exactly what is checked.
