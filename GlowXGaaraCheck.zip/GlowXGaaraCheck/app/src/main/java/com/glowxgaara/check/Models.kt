package com.glowxgaara.check

enum class Severity { OK, INFO, WARN, FAIL }

data class Finding(
    val title: String,
    val detail: String = "",
    val severity: Severity = Severity.INFO
)

data class Section(val name: String, val findings: List<Finding>)

fun List<Section>.verdict(): Severity =
    flatMap { it.findings }.maxOfOrNull { it.severity } ?: Severity.OK
